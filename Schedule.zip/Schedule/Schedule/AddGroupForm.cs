﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class AddGroupForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";
        public AddGroupForm()
        {
            InitializeComponent();
            LoadCourses();
        }

        // Загрузка курсов в courseComboBox
        private void LoadCourses()
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT id, name FROM courses ORDER BY name";
                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        var adapter = new NpgsqlDataAdapter(command);
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Настраиваем ComboBox
                        courseComboBox.DataSource = dataTable;
                        courseComboBox.DisplayMember = "name"; // Отображаемое значение
                        courseComboBox.ValueMember = "id";     // Значение для использования
                        courseComboBox.SelectedIndex = -1;    // По умолчанию ничего не выбрано
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке курсов: {ex.Message}", "Ошибка");
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Получаем введенное название группы из текстового поля
            string groupName = groupNameTextBox.Text.Trim();

            // Проверяем, что поле не пустое
            if (string.IsNullOrWhiteSpace(groupName))
            {
                MessageBox.Show("Введите название группы.", "Внимание");
                return;
            }

            // Проверяем, что выбран курс
            if (courseComboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите курс.", "Внимание");
                return;
            }

            // Получаем выбранный курс
            int selectedCourseId = Convert.ToInt32(courseComboBox.SelectedValue);

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверяем, существует ли уже такая группа
                    string checkQuery = "SELECT COUNT(*) FROM groups WHERE name = @GroupName";
                    using (var checkCommand = new NpgsqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@GroupName", groupName);
                        int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("Группа с таким названием уже существует.", "Ошибка");
                            return;
                        }
                    }

                    // Добавляем новую группу с указанным курсом
                    string insertQuery = "INSERT INTO groups (name, course_id) VALUES (@GroupName, @CourseId)";
                    using (var insertCommand = new NpgsqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@GroupName", groupName);
                        insertCommand.Parameters.AddWithValue("@CourseId", selectedCourseId);
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Группа успешно добавлена.", "Успех");
                this.Close(); // Закрываем форму после успешного добавления
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении группы: {ex.Message}", "Ошибка");
            }
        }
    }
}
