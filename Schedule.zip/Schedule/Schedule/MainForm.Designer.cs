﻿namespace Schedule
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel4 = new TableLayoutPanel();
            scheduleButton = new Button();
            tableLayoutPanel3 = new TableLayoutPanel();
            flowLayoutPanel3 = new FlowLayoutPanel();
            subjectsButton = new Button();
            roomsButton = new Button();
            flowLayoutPanel1 = new FlowLayoutPanel();
            groupsButton = new Button();
            professorsButton = new Button();
            flowLayoutPanel5 = new FlowLayoutPanel();
            refreshButton = new Button();
            button4 = new Button();
            flowLayoutPanel2 = new FlowLayoutPanel();
            label9 = new Label();
            courseComboBox = new ComboBox();
            label1 = new Label();
            groupComboBox = new ComboBox();
            label2 = new Label();
            weekTypeComboBox = new ComboBox();
            tableLayoutPanel5 = new TableLayoutPanel();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel11 = new TableLayoutPanel();
            label8 = new Label();
            dataGridView5 = new DataGridView();
            tableLayoutPanel10 = new TableLayoutPanel();
            label7 = new Label();
            dataGridView6 = new DataGridView();
            tableLayoutPanel9 = new TableLayoutPanel();
            label6 = new Label();
            dataGridView4 = new DataGridView();
            tableLayoutPanel8 = new TableLayoutPanel();
            label5 = new Label();
            dataGridView3 = new DataGridView();
            tableLayoutPanel7 = new TableLayoutPanel();
            label4 = new Label();
            dataGridView2 = new DataGridView();
            tableLayoutPanel6 = new TableLayoutPanel();
            label3 = new Label();
            dataGridView1 = new DataGridView();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            flowLayoutPanel3.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            flowLayoutPanel5.SuspendLayout();
            flowLayoutPanel2.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).BeginInit();
            tableLayoutPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).BeginInit();
            tableLayoutPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).BeginInit();
            tableLayoutPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            tableLayoutPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            tableLayoutPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.AutoSize = true;
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel4, 0, 0);
            tableLayoutPanel2.Controls.Add(flowLayoutPanel5, 1, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 744);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 1;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel2.Size = new Size(1076, 156);
            tableLayoutPanel2.TabIndex = 21;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.AutoSize = true;
            tableLayoutPanel4.ColumnCount = 1;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel4.Controls.Add(scheduleButton, 0, 0);
            tableLayoutPanel4.Controls.Add(tableLayoutPanel3, 0, 1);
            tableLayoutPanel4.Dock = DockStyle.Left;
            tableLayoutPanel4.Location = new Point(3, 3);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 2;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 30.76923F));
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 69.23077F));
            tableLayoutPanel4.Size = new Size(338, 150);
            tableLayoutPanel4.TabIndex = 23;
            // 
            // scheduleButton
            // 
            scheduleButton.Location = new Point(3, 3);
            scheduleButton.Name = "scheduleButton";
            scheduleButton.Size = new Size(332, 40);
            scheduleButton.TabIndex = 7;
            scheduleButton.Text = "Управление расписанием";
            scheduleButton.UseVisualStyleBackColor = true;
            scheduleButton.Click += scheduleButton_Click;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.AutoSize = true;
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel3.Controls.Add(flowLayoutPanel3, 1, 0);
            tableLayoutPanel3.Controls.Add(flowLayoutPanel1, 0, 0);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 49);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 1;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.Size = new Size(332, 98);
            tableLayoutPanel3.TabIndex = 22;
            // 
            // flowLayoutPanel3
            // 
            flowLayoutPanel3.AutoSize = true;
            flowLayoutPanel3.Controls.Add(subjectsButton);
            flowLayoutPanel3.Controls.Add(roomsButton);
            flowLayoutPanel3.Dock = DockStyle.Right;
            flowLayoutPanel3.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel3.Location = new Point(180, 3);
            flowLayoutPanel3.Name = "flowLayoutPanel3";
            flowLayoutPanel3.Size = new Size(149, 92);
            flowLayoutPanel3.TabIndex = 23;
            // 
            // subjectsButton
            // 
            subjectsButton.Location = new Point(3, 3);
            subjectsButton.Name = "subjectsButton";
            subjectsButton.Size = new Size(143, 29);
            subjectsButton.TabIndex = 5;
            subjectsButton.Text = "Предметы";
            subjectsButton.UseVisualStyleBackColor = true;
            subjectsButton.Click += subjectsButton_Click;
            // 
            // roomsButton
            // 
            roomsButton.Location = new Point(3, 38);
            roomsButton.Name = "roomsButton";
            roomsButton.Size = new Size(143, 29);
            roomsButton.TabIndex = 8;
            roomsButton.Text = "Аудитории";
            roomsButton.UseVisualStyleBackColor = true;
            roomsButton.Click += roomsButton_Click;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.AutoSize = true;
            flowLayoutPanel1.Controls.Add(groupsButton);
            flowLayoutPanel1.Controls.Add(professorsButton);
            flowLayoutPanel1.Dock = DockStyle.Left;
            flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel1.Location = new Point(3, 3);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(149, 92);
            flowLayoutPanel1.TabIndex = 19;
            // 
            // groupsButton
            // 
            groupsButton.Location = new Point(3, 3);
            groupsButton.Name = "groupsButton";
            groupsButton.Size = new Size(143, 29);
            groupsButton.TabIndex = 3;
            groupsButton.Text = "Группы";
            groupsButton.UseVisualStyleBackColor = true;
            groupsButton.Click += groupsButton_Click;
            // 
            // professorsButton
            // 
            professorsButton.Location = new Point(3, 38);
            professorsButton.Name = "professorsButton";
            professorsButton.Size = new Size(143, 29);
            professorsButton.TabIndex = 4;
            professorsButton.Text = "Преподаватели";
            professorsButton.UseVisualStyleBackColor = true;
            professorsButton.Click += professorsButton_Click;
            // 
            // flowLayoutPanel5
            // 
            flowLayoutPanel5.AutoSize = true;
            flowLayoutPanel5.Controls.Add(refreshButton);
            flowLayoutPanel5.Controls.Add(button4);
            flowLayoutPanel5.Dock = DockStyle.Right;
            flowLayoutPanel5.FlowDirection = FlowDirection.TopDown;
            flowLayoutPanel5.Location = new Point(775, 3);
            flowLayoutPanel5.Name = "flowLayoutPanel5";
            flowLayoutPanel5.Size = new Size(298, 150);
            flowLayoutPanel5.TabIndex = 22;
            // 
            // refreshButton
            // 
            refreshButton.AutoSize = true;
            refreshButton.Location = new Point(3, 3);
            refreshButton.Name = "refreshButton";
            refreshButton.Size = new Size(292, 40);
            refreshButton.TabIndex = 9;
            refreshButton.Text = "Обновить расписание";
            refreshButton.UseVisualStyleBackColor = true;
            refreshButton.Click += refreshButton_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.GreenYellow;
            button4.Location = new Point(3, 49);
            button4.Name = "button4";
            button4.Size = new Size(292, 40);
            button4.TabIndex = 6;
            button4.Text = "Экспорт в Excel";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // flowLayoutPanel2
            // 
            flowLayoutPanel2.AutoSize = true;
            flowLayoutPanel2.Controls.Add(label9);
            flowLayoutPanel2.Controls.Add(courseComboBox);
            flowLayoutPanel2.Controls.Add(label1);
            flowLayoutPanel2.Controls.Add(groupComboBox);
            flowLayoutPanel2.Controls.Add(label2);
            flowLayoutPanel2.Controls.Add(weekTypeComboBox);
            flowLayoutPanel2.Dock = DockStyle.Fill;
            flowLayoutPanel2.Location = new Point(3, 3);
            flowLayoutPanel2.Name = "flowLayoutPanel2";
            flowLayoutPanel2.Size = new Size(1076, 36);
            flowLayoutPanel2.TabIndex = 20;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label9.Location = new Point(3, 0);
            label9.Name = "label9";
            label9.Size = new Size(48, 23);
            label9.TabIndex = 18;
            label9.Text = "Курс";
            // 
            // courseComboBox
            // 
            courseComboBox.DisplayMember = "name";
            courseComboBox.FormattingEnabled = true;
            courseComboBox.Location = new Point(57, 3);
            courseComboBox.Name = "courseComboBox";
            courseComboBox.Size = new Size(151, 28);
            courseComboBox.TabIndex = 19;
            courseComboBox.ValueMember = "id";
            courseComboBox.SelectedIndexChanged += courseComboBox_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.Location = new Point(214, 0);
            label1.Name = "label1";
            label1.Size = new Size(67, 23);
            label1.TabIndex = 0;
            label1.Text = "Группа";
            // 
            // groupComboBox
            // 
            groupComboBox.DisplayMember = "name";
            groupComboBox.FormattingEnabled = true;
            groupComboBox.Location = new Point(287, 3);
            groupComboBox.Name = "groupComboBox";
            groupComboBox.Size = new Size(151, 28);
            groupComboBox.TabIndex = 1;
            groupComboBox.ValueMember = "id";
            groupComboBox.SelectedIndexChanged += groupComboBox_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label2.Location = new Point(444, 0);
            label2.Name = "label2";
            label2.Size = new Size(72, 23);
            label2.TabIndex = 16;
            label2.Text = "Неделя";
            // 
            // weekTypeComboBox
            // 
            weekTypeComboBox.DisplayMember = "name";
            weekTypeComboBox.FormattingEnabled = true;
            weekTypeComboBox.Location = new Point(522, 3);
            weekTypeComboBox.Name = "weekTypeComboBox";
            weekTypeComboBox.Size = new Size(151, 28);
            weekTypeComboBox.TabIndex = 17;
            weekTypeComboBox.ValueMember = "id";
            weekTypeComboBox.SelectedIndexChanged += weekTypeComboBox_SelectedIndexChanged;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.AutoSize = true;
            tableLayoutPanel5.BackColor = Color.White;
            tableLayoutPanel5.ColumnCount = 1;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel5.Controls.Add(flowLayoutPanel2, 0, 0);
            tableLayoutPanel5.Controls.Add(tableLayoutPanel2, 0, 2);
            tableLayoutPanel5.Controls.Add(tableLayoutPanel1, 0, 1);
            tableLayoutPanel5.Dock = DockStyle.Fill;
            tableLayoutPanel5.Location = new Point(0, 0);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 3;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 4.71380472F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 77.51938F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 17.8294582F));
            tableLayoutPanel5.Size = new Size(1082, 903);
            tableLayoutPanel5.TabIndex = 22;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.AutoSize = true;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49.9999962F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50.0000076F));
            tableLayoutPanel1.Controls.Add(tableLayoutPanel11, 0, 2);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel10, 1, 2);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel9, 1, 1);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel8, 0, 1);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel7, 1, 0);
            tableLayoutPanel1.Controls.Add(tableLayoutPanel6, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(3, 45);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 3;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanel1.Size = new Size(1076, 693);
            tableLayoutPanel1.TabIndex = 18;
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.ColumnCount = 1;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel11.Controls.Add(label8, 0, 0);
            tableLayoutPanel11.Controls.Add(dataGridView5, 0, 1);
            tableLayoutPanel11.Dock = DockStyle.Fill;
            tableLayoutPanel11.Location = new Point(3, 465);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 2;
            tableLayoutPanel11.RowStyles.Add(new RowStyle());
            tableLayoutPanel11.RowStyles.Add(new RowStyle());
            tableLayoutPanel11.Size = new Size(531, 225);
            tableLayoutPanel11.TabIndex = 23;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Dock = DockStyle.Bottom;
            label8.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label8.Location = new Point(3, 0);
            label8.Name = "label8";
            label8.Size = new Size(525, 23);
            label8.TabIndex = 29;
            label8.Text = "Пятница";
            label8.TextAlign = ContentAlignment.BottomCenter;
            // 
            // dataGridView5
            // 
            dataGridView5.AllowUserToAddRows = false;
            dataGridView5.AllowUserToDeleteRows = false;
            dataGridView5.BackgroundColor = Color.White;
            dataGridView5.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView5.Dock = DockStyle.Fill;
            dataGridView5.GridColor = Color.DimGray;
            dataGridView5.Location = new Point(0, 23);
            dataGridView5.Margin = new Padding(0);
            dataGridView5.Name = "dataGridView5";
            dataGridView5.RowHeadersWidth = 51;
            dataGridView5.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView5.Size = new Size(531, 202);
            dataGridView5.TabIndex = 14;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.ColumnCount = 1;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel10.Controls.Add(label7, 0, 0);
            tableLayoutPanel10.Controls.Add(dataGridView6, 0, 1);
            tableLayoutPanel10.Dock = DockStyle.Fill;
            tableLayoutPanel10.Location = new Point(540, 465);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 2;
            tableLayoutPanel10.RowStyles.Add(new RowStyle());
            tableLayoutPanel10.RowStyles.Add(new RowStyle());
            tableLayoutPanel10.Size = new Size(533, 225);
            tableLayoutPanel10.TabIndex = 23;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Dock = DockStyle.Bottom;
            label7.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label7.Location = new Point(3, 0);
            label7.Name = "label7";
            label7.Size = new Size(527, 23);
            label7.TabIndex = 28;
            label7.Text = "Суббота";
            label7.TextAlign = ContentAlignment.BottomCenter;
            // 
            // dataGridView6
            // 
            dataGridView6.AllowUserToAddRows = false;
            dataGridView6.AllowUserToDeleteRows = false;
            dataGridView6.BackgroundColor = Color.White;
            dataGridView6.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView6.Dock = DockStyle.Fill;
            dataGridView6.GridColor = Color.DimGray;
            dataGridView6.Location = new Point(0, 23);
            dataGridView6.Margin = new Padding(0);
            dataGridView6.Name = "dataGridView6";
            dataGridView6.RowHeadersWidth = 51;
            dataGridView6.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView6.Size = new Size(533, 202);
            dataGridView6.TabIndex = 15;
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.ColumnCount = 1;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel9.Controls.Add(label6, 0, 0);
            tableLayoutPanel9.Controls.Add(dataGridView4, 0, 1);
            tableLayoutPanel9.Dock = DockStyle.Fill;
            tableLayoutPanel9.Location = new Point(540, 234);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 2;
            tableLayoutPanel9.RowStyles.Add(new RowStyle());
            tableLayoutPanel9.RowStyles.Add(new RowStyle());
            tableLayoutPanel9.Size = new Size(533, 225);
            tableLayoutPanel9.TabIndex = 23;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Dock = DockStyle.Bottom;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label6.Location = new Point(3, 0);
            label6.Name = "label6";
            label6.Size = new Size(527, 23);
            label6.TabIndex = 27;
            label6.Text = "Четверг";
            label6.TextAlign = ContentAlignment.BottomCenter;
            // 
            // dataGridView4
            // 
            dataGridView4.AllowUserToAddRows = false;
            dataGridView4.AllowUserToDeleteRows = false;
            dataGridView4.BackgroundColor = Color.White;
            dataGridView4.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView4.Dock = DockStyle.Fill;
            dataGridView4.GridColor = Color.DimGray;
            dataGridView4.Location = new Point(0, 23);
            dataGridView4.Margin = new Padding(0);
            dataGridView4.Name = "dataGridView4";
            dataGridView4.RowHeadersWidth = 51;
            dataGridView4.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView4.Size = new Size(533, 202);
            dataGridView4.TabIndex = 13;
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 1;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel8.Controls.Add(label5, 0, 0);
            tableLayoutPanel8.Controls.Add(dataGridView3, 0, 1);
            tableLayoutPanel8.Dock = DockStyle.Fill;
            tableLayoutPanel8.Location = new Point(3, 234);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 2;
            tableLayoutPanel8.RowStyles.Add(new RowStyle());
            tableLayoutPanel8.RowStyles.Add(new RowStyle());
            tableLayoutPanel8.Size = new Size(531, 225);
            tableLayoutPanel8.TabIndex = 23;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Dock = DockStyle.Bottom;
            label5.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label5.Location = new Point(3, 0);
            label5.Name = "label5";
            label5.Size = new Size(525, 23);
            label5.TabIndex = 26;
            label5.Text = "Среда";
            label5.TextAlign = ContentAlignment.BottomCenter;
            // 
            // dataGridView3
            // 
            dataGridView3.AllowUserToAddRows = false;
            dataGridView3.AllowUserToDeleteRows = false;
            dataGridView3.BackgroundColor = Color.White;
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Dock = DockStyle.Fill;
            dataGridView3.GridColor = Color.DimGray;
            dataGridView3.Location = new Point(0, 23);
            dataGridView3.Margin = new Padding(0);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowHeadersWidth = 51;
            dataGridView3.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView3.Size = new Size(531, 202);
            dataGridView3.TabIndex = 12;
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 1;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel7.Controls.Add(label4, 0, 0);
            tableLayoutPanel7.Controls.Add(dataGridView2, 0, 1);
            tableLayoutPanel7.Dock = DockStyle.Fill;
            tableLayoutPanel7.Location = new Point(540, 3);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 2;
            tableLayoutPanel7.RowStyles.Add(new RowStyle());
            tableLayoutPanel7.RowStyles.Add(new RowStyle());
            tableLayoutPanel7.Size = new Size(533, 225);
            tableLayoutPanel7.TabIndex = 23;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Bottom;
            label4.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label4.Location = new Point(3, 0);
            label4.Name = "label4";
            label4.Size = new Size(527, 23);
            label4.TabIndex = 25;
            label4.Text = "Вторник";
            label4.TextAlign = ContentAlignment.BottomCenter;
            // 
            // dataGridView2
            // 
            dataGridView2.AllowUserToAddRows = false;
            dataGridView2.AllowUserToDeleteRows = false;
            dataGridView2.BackgroundColor = Color.White;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Dock = DockStyle.Fill;
            dataGridView2.GridColor = Color.DimGray;
            dataGridView2.Location = new Point(0, 23);
            dataGridView2.Margin = new Padding(0);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowHeadersWidth = 51;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.Size = new Size(533, 202);
            dataGridView2.TabIndex = 11;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 1;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel6.Controls.Add(label3, 0, 0);
            tableLayoutPanel6.Controls.Add(dataGridView1, 0, 1);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(3, 3);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 2;
            tableLayoutPanel6.RowStyles.Add(new RowStyle());
            tableLayoutPanel6.RowStyles.Add(new RowStyle());
            tableLayoutPanel6.Size = new Size(531, 225);
            tableLayoutPanel6.TabIndex = 23;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Bottom;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(525, 23);
            label3.TabIndex = 24;
            label3.Text = "Понедельник";
            label3.TextAlign = ContentAlignment.BottomCenter;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.GridColor = Color.DimGray;
            dataGridView1.Location = new Point(0, 23);
            dataGridView1.Margin = new Padding(0);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(531, 202);
            dataGridView1.TabIndex = 10;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoScroll = true;
            BackColor = Color.White;
            ClientSize = new Size(1082, 903);
            Controls.Add(tableLayoutPanel5);
            Name = "MainForm";
            Text = "Расписание";
            Resize += MainForm_Resize;
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel3.PerformLayout();
            flowLayoutPanel3.ResumeLayout(false);
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel5.ResumeLayout(false);
            flowLayoutPanel5.PerformLayout();
            flowLayoutPanel2.ResumeLayout(false);
            flowLayoutPanel2.PerformLayout();
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel11.ResumeLayout(false);
            tableLayoutPanel11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView5).EndInit();
            tableLayoutPanel10.ResumeLayout(false);
            tableLayoutPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView6).EndInit();
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView4).EndInit();
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel4;
        private Button scheduleButton;
        private TableLayoutPanel tableLayoutPanel3;
        private FlowLayoutPanel flowLayoutPanel3;
        private Button subjectsButton;
        private Button roomsButton;
        private FlowLayoutPanel flowLayoutPanel1;
        private Button groupsButton;
        private Button professorsButton;
        private FlowLayoutPanel flowLayoutPanel5;
        private Button refreshButton;
        private Button button4;
        private FlowLayoutPanel flowLayoutPanel2;
        private Label label1;
        private ComboBox groupComboBox;
        private Label label2;
        private ComboBox weekTypeComboBox;
        private TableLayoutPanel tableLayoutPanel5;
        private TableLayoutPanel tableLayoutPanel1;
        private TableLayoutPanel tableLayoutPanel11;
        private Label label8;
        private DataGridView dataGridView5;
        private TableLayoutPanel tableLayoutPanel10;
        private Label label7;
        private DataGridView dataGridView6;
        private TableLayoutPanel tableLayoutPanel9;
        private Label label6;
        private DataGridView dataGridView4;
        private TableLayoutPanel tableLayoutPanel8;
        private Label label5;
        private DataGridView dataGridView3;
        private TableLayoutPanel tableLayoutPanel7;
        private Label label4;
        private DataGridView dataGridView2;
        private TableLayoutPanel tableLayoutPanel6;
        private Label label3;
        private DataGridView dataGridView1;
        private Label label9;
        private ComboBox courseComboBox;
    }
}
