﻿namespace Schedule
{
    partial class AddGroupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelNum = new Label();
            buttonSave = new Button();
            groupNameTextBox = new TextBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            tableLayoutPanel2 = new TableLayoutPanel();
            label1 = new Label();
            courseComboBox = new ComboBox();
            tableLayoutPanel1.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // labelNum
            // 
            labelNum.AutoSize = true;
            labelNum.Dock = DockStyle.Top;
            labelNum.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelNum.Location = new Point(3, 0);
            labelNum.Name = "labelNum";
            labelNum.Size = new Size(184, 23);
            labelNum.TabIndex = 22;
            labelNum.Text = "Название группы";
            labelNum.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // buttonSave
            // 
            buttonSave.Dock = DockStyle.Fill;
            buttonSave.Location = new Point(3, 169);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(476, 51);
            buttonSave.TabIndex = 23;
            buttonSave.Text = "Добавить";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // groupNameTextBox
            // 
            groupNameTextBox.Dock = DockStyle.Top;
            groupNameTextBox.Location = new Point(193, 3);
            groupNameTextBox.Name = "groupNameTextBox";
            groupNameTextBox.Size = new Size(280, 27);
            groupNameTextBox.TabIndex = 24;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.Controls.Add(tableLayoutPanel2, 0, 0);
            tableLayoutPanel1.Controls.Add(buttonSave, 0, 1);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 2;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 74.43946F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 25.5605373F));
            tableLayoutPanel1.Size = new Size(482, 223);
            tableLayoutPanel1.TabIndex = 25;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 60F));
            tableLayoutPanel2.Controls.Add(label1, 0, 1);
            tableLayoutPanel2.Controls.Add(groupNameTextBox, 1, 0);
            tableLayoutPanel2.Controls.Add(labelNum, 0, 0);
            tableLayoutPanel2.Controls.Add(courseComboBox, 1, 1);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 3);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 2;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 35F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 65F));
            tableLayoutPanel2.Size = new Size(476, 160);
            tableLayoutPanel2.TabIndex = 26;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ImageAlign = ContentAlignment.MiddleLeft;
            label1.Location = new Point(3, 56);
            label1.Name = "label1";
            label1.Size = new Size(184, 23);
            label1.TabIndex = 25;
            label1.Text = "Курс";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // courseComboBox
            // 
            courseComboBox.Dock = DockStyle.Top;
            courseComboBox.FormattingEnabled = true;
            courseComboBox.Location = new Point(193, 59);
            courseComboBox.Name = "courseComboBox";
            courseComboBox.Size = new Size(280, 28);
            courseComboBox.TabIndex = 26;
            // 
            // AddGroupForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(482, 223);
            Controls.Add(tableLayoutPanel1);
            Name = "AddGroupForm";
            Text = "Добавить группу";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label labelNum;
        private Button buttonSave;
        private TextBox groupNameTextBox;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label1;
        private TableLayoutPanel tableLayoutPanel2;
        private ComboBox courseComboBox;
    }
}