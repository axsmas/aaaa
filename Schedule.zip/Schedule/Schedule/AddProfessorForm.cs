﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class AddProfessorForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";

        public AddProfessorForm()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Получаем введённое имя преподавателя из текстового поля
            string professorName = professorNameTextBox.Text.Trim();

            // Проверяем, что поле не пустое
            if (string.IsNullOrWhiteSpace(professorName))
            {
                MessageBox.Show("Введите имя преподавателя.", "Внимание");
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверяем, существует ли уже такой преподаватель
                    string checkQuery = "SELECT COUNT(*) FROM professors WHERE name = @ProfessorName";
                    using (var checkCommand = new NpgsqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@ProfessorName", professorName);
                        int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("Преподаватель с таким именем уже существует.", "Ошибка");
                            return;
                        }
                    }

                    // Добавляем нового преподавателя
                    string insertQuery = "INSERT INTO professors (name) VALUES (@ProfessorName)";
                    using (var insertCommand = new NpgsqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@ProfessorName", professorName);
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Преподаватель успешно добавлен.", "Успех");
                this.Close(); // Закрываем форму после успешного добавления
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении преподавателя: {ex.Message}", "Ошибка");
            }
        }
    }
}
