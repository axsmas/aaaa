﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class RoomForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";
        public RoomForm()
        {
            InitializeComponent();
            LoadRoomsTable();
        }

        private void LoadRoomsTable(string filter = "")
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Базовый запрос
                    string query = "SELECT id, name FROM rooms";

                    // Если указан фильтр, добавляем условие WHERE
                    if (!string.IsNullOrWhiteSpace(filter))
                    {
                        query += " WHERE name ILIKE @Filter";
                    }

                    query += " ORDER BY name";

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        if (!string.IsNullOrWhiteSpace(filter))
                        {
                            command.Parameters.AddWithValue("@Filter", $"%{filter}%");
                        }

                        var adapter = new NpgsqlDataAdapter(command);
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridView.DataSource = dataTable;

                        // Устанавливаем пользовательские заголовки столбцов
                        if (dataGridView.Columns.Count > 0)
                        {
                            dataGridView.Columns["id"].HeaderText = "ID";
                            dataGridView.Columns["name"].HeaderText = "Название помещения";
                            dataGridView.Columns["id"].Visible = false; // Скрываем колонку ID
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке таблицы помещений: {ex.Message}", "Ошибка");
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Открытие формы для добавления помещения
            AddRoomForm addRoomForm = new AddRoomForm();
            addRoomForm.ShowDialog();

            // Обновляем данные после добавления
            LoadRoomsTable();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView.SelectedRows.Count > 0)
            {
                var id = dataGridView.SelectedRows[0].Cells["id"].Value;

                try
                {
                    using (var connection = new NpgsqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM rooms WHERE id = @Id";
                        using (var command = new NpgsqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Id", id);
                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Помещение успешно удалено.", "Успех");
                    LoadRoomsTable(); // Обновляем DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении помещения: {ex.Message}", "Ошибка");
                }
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления.", "Внимание");
            }
        }

        private void textBoxProfessorSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBoxRoomSearch.Text.Trim();
            LoadRoomsTable(searchText);
        }
    }
}
