﻿using System;
using System.Data;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class ScheduleForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";

        public ScheduleForm()
        {
            InitializeComponent();
            LoadGroups(); // Загружаем список групп
            LoadSchedule(); // Загружаем расписание
        }

        // Загрузка расписания с фильтром по группе
        private void LoadSchedule()
        {
            try
            {
                // Очищаем старые строки перед загрузкой новых
                dataGridViewSchedule.DataSource = null; // Отвязываем старые данные
                dataGridViewSchedule.Rows.Clear(); // Очистка строк

                // Получаем ID выбранной группы
                int selectedGroupId = 0;
                if (comboBoxGroupFilter.SelectedValue != null && int.TryParse(comboBoxGroupFilter.SelectedValue.ToString(), out selectedGroupId))
                {
                    Console.WriteLine($"ID выбранной группы: {selectedGroupId}");
                }

                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"SELECT 
                                ts.id, 
                                ts.class_num, 
                                g.name AS group_name, 
                                s.name AS subject, 
                                p.name AS professor, 
                                r.name AS room, 
                                d.name AS day,
                                wt.name AS week_type,
                                ts.start_time, 
                                ts.end_time 
                             FROM schedule ts
                             JOIN groups g ON ts.group_id = g.id
                             JOIN subjects s ON ts.subject_id = s.id
                             JOIN professors p ON ts.professor_id = p.id
                             JOIN rooms r ON ts.room_id = r.id
                             JOIN dayofweek d ON ts.dayofweek_id = d.id
                             JOIN weektype wt ON ts.weektype_id = wt.id";

                    if (selectedGroupId != 0)
                    {
                        query += " WHERE g.id = @GroupId";
                    }

                    query += " ORDER BY ts.class_num ASC, d.id, ts.start_time";

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        if (selectedGroupId != 0)
                        {
                            command.Parameters.AddWithValue("@GroupId", selectedGroupId);
                        }

                        var adapter = new NpgsqlDataAdapter(command);
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Присваиваем данные в DataGridView
                        dataGridViewSchedule.DataSource = dataTable;

                        // Устанавливаем пользовательские названия столбцов
                        if (dataGridViewSchedule.Columns.Count > 0)
                        {
                            dataGridViewSchedule.Columns["class_num"].HeaderText = "Номер пары"; // Теперь это первый столбец

                            if (dataGridViewSchedule.Columns.Contains("id"))
                            {
                                dataGridViewSchedule.Columns["id"].HeaderText = "ID";
                                dataGridViewSchedule.Columns["id"].Visible = false; // Скрываем столбец "id"
                            }

                            dataGridViewSchedule.Columns["group_name"].HeaderText = "Группа";
                            dataGridViewSchedule.Columns["subject"].HeaderText = "Предмет";
                            dataGridViewSchedule.Columns["professor"].HeaderText = "Преподаватель";
                            dataGridViewSchedule.Columns["room"].HeaderText = "Аудитория";
                            dataGridViewSchedule.Columns["day"].HeaderText = "День недели";
                            dataGridViewSchedule.Columns["week_type"].HeaderText = "Тип недели";
                            dataGridViewSchedule.Columns["start_time"].HeaderText = "Время начала";
                            dataGridViewSchedule.Columns["end_time"].HeaderText = "Время окончания";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке расписания: {ex.Message}", "Ошибка");
            }
        }



        // Загрузка списка групп в ComboBox
        private void LoadGroups()
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    string query = "SELECT id, name FROM groups ORDER BY name";
                    var adapter = new NpgsqlDataAdapter(query, connection);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Добавляем пункт "Все группы"
                    var allGroupsRow = dataTable.NewRow();
                    allGroupsRow["id"] = 0;
                    allGroupsRow["name"] = "Все группы";
                    dataTable.Rows.InsertAt(allGroupsRow, 0);

                    comboBoxGroupFilter.DataSource = dataTable;
                    comboBoxGroupFilter.DisplayMember = "name";
                    comboBoxGroupFilter.ValueMember = "id";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке групп: {ex.Message}", "Ошибка");
            }
        }


        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Получаем ID выбранной группы
            var selectedGroupId = (int)comboBoxGroupFilter.SelectedValue;

            // Открываем форму для добавления нового занятия и передаем ID группы
            AddScheduleForm addScheduleForm = new AddScheduleForm(selectedGroupId);
            addScheduleForm.ShowDialog();

            // Перезагружаем расписание после добавления
            LoadSchedule(); // Используем LoadSchedule, так как этот метод уже загружает обновленное расписание
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewSchedule.SelectedRows.Count > 0)
            {
                // Получаем id занятия
                var id = dataGridViewSchedule.SelectedRows[0].Cells["id"].Value;

                try
                {
                    using (var connection = new NpgsqlConnection(connectionString))
                    {
                        connection.Open();

                        var query = "DELETE FROM schedule WHERE id = @Id";
                        using (var command = new NpgsqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Id", id);
                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Занятие успешно удалено.", "Успех");
                    LoadSchedule(); // Перезагружаем расписание
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении занятия: {ex.Message}", "Ошибка");
                }
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления.", "Внимание");
            }
        }

        private void comboBoxGroupFilter_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            // Проверяем, что выбрана группа
            if (comboBoxGroupFilter.SelectedValue != null)
            {
                // Преобразуем SelectedValue в DataRowView
                DataRowView selectedRow = comboBoxGroupFilter.SelectedItem as DataRowView;

                // Если конвертация успешна, извлекаем id
                if (selectedRow != null)
                {
                    int selectedGroupId = Convert.ToInt32(selectedRow["id"]);

                    // Отключаем или включаем кнопку "Добавить" в зависимости от выбора
                    buttonAdd.Enabled = selectedGroupId != 0;

                    // Выводим информацию для отладки
                    Console.WriteLine($"Выбранная группа: {selectedGroupId}");

                    // Перезагружаем расписание при изменении группы
                    LoadSchedule();
                }
            }
        }
    }
}