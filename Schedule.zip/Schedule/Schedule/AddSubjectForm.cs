﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class AddSubjectForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";
        public AddSubjectForm()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Получаем введённое название предмета из текстового поля
            string subjectName = subjectNameTextBox.Text.Trim();

            // Проверяем, что поле не пустое
            if (string.IsNullOrWhiteSpace(subjectName))
            {
                MessageBox.Show("Введите название предмета.", "Внимание");
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверяем, существует ли уже такой предмет
                    string checkQuery = "SELECT COUNT(*) FROM subjects WHERE name = @SubjectName";
                    using (var checkCommand = new NpgsqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@SubjectName", subjectName);
                        int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("Предмет с таким названием уже существует.", "Ошибка");
                            return;
                        }
                    }

                    // Добавляем новый предмет в таблицу subjects
                    string insertQuery = "INSERT INTO subjects (name) VALUES (@SubjectName)";
                    using (var insertCommand = new NpgsqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@SubjectName", subjectName);
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Предмет успешно добавлен.", "Успех");
                this.Close(); // Закрываем форму после успешного добавления
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении предмета: {ex.Message}", "Ошибка");
            }
        }
    }
}
