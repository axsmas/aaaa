﻿namespace Schedule
{
    partial class AddScheduleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelSubj = new Label();
            labelProf = new Label();
            labelRoom = new Label();
            labelDay = new Label();
            labelTimeSt = new Label();
            labelTimeEnd = new Label();
            buttonSave = new Button();
            comboBoxSubject = new ComboBox();
            comboBoxProfessor = new ComboBox();
            comboBoxRoom = new ComboBox();
            comboBoxDay = new ComboBox();
            dateTimePickerStartTime = new DateTimePicker();
            dateTimePickerEndTime = new DateTimePicker();
            classNumComboBox = new ComboBox();
            labelNum = new Label();
            comboBoxWeekType = new ComboBox();
            labelWeekType = new Label();
            SuspendLayout();
            // 
            // labelSubj
            // 
            labelSubj.AutoSize = true;
            labelSubj.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelSubj.Location = new Point(14, 215);
            labelSubj.Name = "labelSubj";
            labelSubj.Size = new Size(84, 23);
            labelSubj.TabIndex = 6;
            labelSubj.Text = "Предмет";
            // 
            // labelProf
            // 
            labelProf.AutoSize = true;
            labelProf.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelProf.Location = new Point(14, 135);
            labelProf.Name = "labelProf";
            labelProf.Size = new Size(139, 23);
            labelProf.TabIndex = 7;
            labelProf.Text = "Преподаватель";
            // 
            // labelRoom
            // 
            labelRoom.AutoSize = true;
            labelRoom.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelRoom.Location = new Point(14, 175);
            labelRoom.Name = "labelRoom";
            labelRoom.Size = new Size(102, 23);
            labelRoom.TabIndex = 8;
            labelRoom.Text = "Аудитория";
            // 
            // labelDay
            // 
            labelDay.AutoSize = true;
            labelDay.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelDay.Location = new Point(14, 55);
            labelDay.Name = "labelDay";
            labelDay.Size = new Size(117, 23);
            labelDay.TabIndex = 9;
            labelDay.Text = "День недели";
            // 
            // labelTimeSt
            // 
            labelTimeSt.AutoSize = true;
            labelTimeSt.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelTimeSt.Location = new Point(14, 255);
            labelTimeSt.Name = "labelTimeSt";
            labelTimeSt.Size = new Size(126, 23);
            labelTimeSt.TabIndex = 10;
            labelTimeSt.Text = "Время начала";
            // 
            // labelTimeEnd
            // 
            labelTimeEnd.AutoSize = true;
            labelTimeEnd.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelTimeEnd.Location = new Point(14, 295);
            labelTimeEnd.Name = "labelTimeEnd";
            labelTimeEnd.Size = new Size(159, 23);
            labelTimeEnd.TabIndex = 11;
            labelTimeEnd.Text = "Время окончания";
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(14, 335);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(152, 45);
            buttonSave.TabIndex = 12;
            buttonSave.Text = "Добавить";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // comboBoxSubject
            // 
            comboBoxSubject.FormattingEnabled = true;
            comboBoxSubject.Location = new Point(190, 215);
            comboBoxSubject.Name = "comboBoxSubject";
            comboBoxSubject.Size = new Size(151, 28);
            comboBoxSubject.TabIndex = 13;
            // 
            // comboBoxProfessor
            // 
            comboBoxProfessor.FormattingEnabled = true;
            comboBoxProfessor.Location = new Point(190, 135);
            comboBoxProfessor.Name = "comboBoxProfessor";
            comboBoxProfessor.Size = new Size(151, 28);
            comboBoxProfessor.TabIndex = 14;
            // 
            // comboBoxRoom
            // 
            comboBoxRoom.FormattingEnabled = true;
            comboBoxRoom.Location = new Point(190, 175);
            comboBoxRoom.Name = "comboBoxRoom";
            comboBoxRoom.Size = new Size(151, 28);
            comboBoxRoom.TabIndex = 15;
            // 
            // comboBoxDay
            // 
            comboBoxDay.FormattingEnabled = true;
            comboBoxDay.Location = new Point(190, 55);
            comboBoxDay.Name = "comboBoxDay";
            comboBoxDay.Size = new Size(151, 28);
            comboBoxDay.TabIndex = 16;
            // 
            // dateTimePickerStartTime
            // 
            dateTimePickerStartTime.Format = DateTimePickerFormat.Time;
            dateTimePickerStartTime.Location = new Point(190, 255);
            dateTimePickerStartTime.Name = "dateTimePickerStartTime";
            dateTimePickerStartTime.Size = new Size(250, 27);
            dateTimePickerStartTime.TabIndex = 17;
            // 
            // dateTimePickerEndTime
            // 
            dateTimePickerEndTime.Format = DateTimePickerFormat.Time;
            dateTimePickerEndTime.Location = new Point(190, 292);
            dateTimePickerEndTime.Name = "dateTimePickerEndTime";
            dateTimePickerEndTime.Size = new Size(250, 27);
            dateTimePickerEndTime.TabIndex = 18;
            // 
            // classNumComboBox
            // 
            classNumComboBox.FormattingEnabled = true;
            classNumComboBox.Location = new Point(190, 15);
            classNumComboBox.Name = "classNumComboBox";
            classNumComboBox.Size = new Size(151, 28);
            classNumComboBox.TabIndex = 19;
            // 
            // labelNum
            // 
            labelNum.AutoSize = true;
            labelNum.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelNum.Location = new Point(14, 15);
            labelNum.Name = "labelNum";
            labelNum.Size = new Size(115, 23);
            labelNum.TabIndex = 20;
            labelNum.Text = "Номер пары";
            // 
            // comboBoxWeekType
            // 
            comboBoxWeekType.FormattingEnabled = true;
            comboBoxWeekType.Location = new Point(190, 95);
            comboBoxWeekType.Name = "comboBoxWeekType";
            comboBoxWeekType.Size = new Size(151, 28);
            comboBoxWeekType.TabIndex = 23;
            // 
            // labelWeekType
            // 
            labelWeekType.AutoSize = true;
            labelWeekType.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelWeekType.Location = new Point(14, 95);
            labelWeekType.Name = "labelWeekType";
            labelWeekType.Size = new Size(72, 23);
            labelWeekType.TabIndex = 22;
            labelWeekType.Text = "Неделя";
            // 
            // AddScheduleForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(467, 393);
            Controls.Add(comboBoxWeekType);
            Controls.Add(labelWeekType);
            Controls.Add(labelNum);
            Controls.Add(classNumComboBox);
            Controls.Add(dateTimePickerEndTime);
            Controls.Add(dateTimePickerStartTime);
            Controls.Add(comboBoxDay);
            Controls.Add(comboBoxRoom);
            Controls.Add(comboBoxProfessor);
            Controls.Add(comboBoxSubject);
            Controls.Add(buttonSave);
            Controls.Add(labelTimeEnd);
            Controls.Add(labelTimeSt);
            Controls.Add(labelDay);
            Controls.Add(labelRoom);
            Controls.Add(labelProf);
            Controls.Add(labelSubj);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Name = "AddScheduleForm";
            Text = "Добавить в расписание";
            Load += AddScheduleForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label labelSubj;
        private Label labelProf;
        private Label labelRoom;
        private Label labelDay;
        private Label labelTimeSt;
        private Label labelTimeEnd;
        private Button buttonSave;
        private ComboBox comboBoxSubject;
        private ComboBox comboBoxProfessor;
        private ComboBox comboBoxRoom;
        private ComboBox comboBoxDay;
        private DateTimePicker dateTimePickerStartTime;
        private DateTimePicker dateTimePickerEndTime;
        private ComboBox classNumComboBox;
        private Label labelNum;
        private ComboBox comboBoxWeekType;
        private Label labelWeekType;
    }
}