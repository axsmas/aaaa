﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class AddScheduleForm : Form
    {
        private int selectedGroupId;
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";
        public AddScheduleForm(int groupId)
        {
            InitializeComponent();
            selectedGroupId = groupId;
        }

        // Загрузка данных для ComboBox
        private void LoadComboBoxData()
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Загружаем предметы
                    string subjectQuery = "SELECT id, name FROM subjects ORDER BY name";
                    var subjectAdapter = new NpgsqlDataAdapter(subjectQuery, connection);
                    var subjectTable = new DataTable();
                    subjectAdapter.Fill(subjectTable);
                    comboBoxSubject.DataSource = subjectTable;
                    comboBoxSubject.DisplayMember = "name";
                    comboBoxSubject.ValueMember = "id";

                    // Загружаем преподавателей
                    string professorQuery = "SELECT id, name FROM professors ORDER BY name";
                    var professorAdapter = new NpgsqlDataAdapter(professorQuery, connection);
                    var professorTable = new DataTable();
                    professorAdapter.Fill(professorTable);
                    comboBoxProfessor.DataSource = professorTable;
                    comboBoxProfessor.DisplayMember = "name";
                    comboBoxProfessor.ValueMember = "id";

                    // Загружаем аудитории
                    string roomQuery = "SELECT id, name FROM rooms ORDER BY name";
                    var roomAdapter = new NpgsqlDataAdapter(roomQuery, connection);
                    var roomTable = new DataTable();
                    roomAdapter.Fill(roomTable);
                    comboBoxRoom.DataSource = roomTable;
                    comboBoxRoom.DisplayMember = "name";
                    comboBoxRoom.ValueMember = "id";

                    // Загружаем дни недели
                    string dayQuery = "SELECT id, name FROM dayofweek ORDER BY id";
                    var dayAdapter = new NpgsqlDataAdapter(dayQuery, connection);
                    var dayTable = new DataTable();
                    dayAdapter.Fill(dayTable);
                    comboBoxDay.DataSource = dayTable;
                    comboBoxDay.DisplayMember = "name";
                    comboBoxDay.ValueMember = "id";

                    // Загружаем номера пары (1–6)
                    classNumComboBox.Items.Clear();
                    for (int i = 1; i <= 6; i++)
                    {
                        classNumComboBox.Items.Add(i);
                    }
                    classNumComboBox.SelectedIndex = 0; // Устанавливаем первую пару по умолчанию

                    // Загружаем типы недели
                    string weekTypeQuery = "SELECT id, name FROM weektype ORDER BY id";
                    var weekTypeAdapter = new NpgsqlDataAdapter(weekTypeQuery, connection);
                    var weekTypeTable = new DataTable();
                    weekTypeAdapter.Fill(weekTypeTable);
                    comboBoxWeekType.DataSource = weekTypeTable;
                    comboBoxWeekType.DisplayMember = "name";
                    comboBoxWeekType.ValueMember = "id";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}", "Ошибка");
            }
        }


        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Получаем значения из комбобоксов
                    int subjectId = (int)comboBoxSubject.SelectedValue;
                    int professorId = (int)comboBoxProfessor.SelectedValue;
                    int roomId = (int)comboBoxRoom.SelectedValue;

                    // Получаем время начала и окончания пары
                    TimeSpan startTime = dateTimePickerStartTime.Value.TimeOfDay;
                    TimeSpan endTime = dateTimePickerEndTime.Value.TimeOfDay;

                    // Получаем номер пары
                    int classNum = (int)classNumComboBox.SelectedItem;

                    // Получаем выбранный тип недели
                    int weekTypeId = (int)comboBoxWeekType.SelectedValue;

                    // Вставка нового занятия в расписание
                    string insertQuery = "INSERT INTO schedule (group_id, subject_id, professor_id, room_id, dayofweek_id, start_time, end_time, class_num, weektype_id) " +
                                         "VALUES (@GroupId, @SubjectId, @ProfessorId, @RoomId, @DayOfWeekId, @StartTime, @EndTime, @ClassNum, @WeekTypeId)";
                    using (var command = new NpgsqlCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@GroupId", selectedGroupId);
                        command.Parameters.AddWithValue("@SubjectId", subjectId);
                        command.Parameters.AddWithValue("@ProfessorId", professorId);
                        command.Parameters.AddWithValue("@RoomId", roomId);
                        command.Parameters.AddWithValue("@DayOfWeekId", (int)comboBoxDay.SelectedValue);
                        command.Parameters.AddWithValue("@StartTime", startTime);
                        command.Parameters.AddWithValue("@EndTime", endTime);
                        command.Parameters.AddWithValue("@ClassNum", classNum);
                        command.Parameters.AddWithValue("@WeekTypeId", weekTypeId);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Занятие успешно добавлено.", "Успех");
                this.Close(); // Закрываем форму после добавления
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении занятия: {ex.Message}", "Ошибка");
            }
        }

        private void AddScheduleForm_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            // Настроим dateTimePickerStartTime для выбора только времени 
            dateTimePickerStartTime.Format = DateTimePickerFormat.Custom;
            dateTimePickerStartTime.CustomFormat = "HH:mm"; // Формат времени (часы и минуты)
            dateTimePickerStartTime.ShowUpDown = true; // Отключаем кнопку календаря

            // Настроим dateTimePickerEndTime для выбора только времени 
            dateTimePickerEndTime.Format = DateTimePickerFormat.Custom;
            dateTimePickerEndTime.CustomFormat = "HH:mm"; // Формат времени (часы и минуты)
            dateTimePickerEndTime.ShowUpDown = true; // Отключаем кнопку календаря 
        }

    }
}
