﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace Schedule
{
    public partial class AddRoomForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";
        public AddRoomForm()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Получаем введённое название помещения из текстового поля
            string roomName = roomNameTextBox.Text.Trim();

            // Проверяем, что поле не пустое
            if (string.IsNullOrWhiteSpace(roomName))
            {
                MessageBox.Show("Введите название помещения.", "Внимание");
                return;
            }

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Проверяем, существует ли уже такое помещение
                    string checkQuery = "SELECT COUNT(*) FROM rooms WHERE name = @RoomName";
                    using (var checkCommand = new NpgsqlCommand(checkQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@RoomName", roomName);
                        int count = Convert.ToInt32(checkCommand.ExecuteScalar());

                        if (count > 0)
                        {
                            MessageBox.Show("Помещение с таким названием уже существует.", "Ошибка");
                            return;
                        }
                    }

                    // Добавляем новое помещение
                    string insertQuery = "INSERT INTO rooms (name) VALUES (@RoomName)";
                    using (var insertCommand = new NpgsqlCommand(insertQuery, connection))
                    {
                        insertCommand.Parameters.AddWithValue("@RoomName", roomName);
                        insertCommand.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Помещение успешно добавлено.", "Успех");
                this.Close(); // Закрываем форму после успешного добавления
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении помещения: {ex.Message}", "Ошибка");
            }
        }
    }
}
