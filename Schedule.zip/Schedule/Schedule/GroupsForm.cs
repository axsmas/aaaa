﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Schedule
{
    public partial class GroupsForm : Form
    {
        private string connectionString = "Server=localhost; Port=5432; Database=UniversitySchedule; User Id=postgres; Password=admin;";

        public GroupsForm()
        {
            InitializeComponent();
            LoadGroupsTable(); // Загружаем данные в DataGridView
        }

        // Загрузка таблицы groups в DataGridView
        private void LoadGroupsTable(string filter = "")
        {
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    // Запрос для загрузки групп с названием курса
                    string query = @"
                        SELECT 
                            g.id, 
                            g.name AS group_name, 
                            c.name AS course_name
                        FROM groups g
                        LEFT JOIN courses c ON g.course_id = c.id";

                    // Если указан фильтр, добавляем условие WHERE
                    if (!string.IsNullOrWhiteSpace(filter))
                    {
                        query += " WHERE g.name ILIKE @Filter";
                    }

                    query += " ORDER BY g.name";

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        if (!string.IsNullOrWhiteSpace(filter))
                        {
                            command.Parameters.AddWithValue("@Filter", $"%{filter}%");
                        }

                        var adapter = new NpgsqlDataAdapter(command);
                        var dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewGroup.DataSource = dataTable;

                        // Устанавливаем пользовательские заголовки столбцов
                        if (dataGridViewGroup.Columns.Count > 0)
                        {
                            dataGridViewGroup.Columns["id"].HeaderText = "ID";
                            dataGridViewGroup.Columns["group_name"].HeaderText = "Название группы";
                            dataGridViewGroup.Columns["course_name"].HeaderText = "Курс";
                            dataGridViewGroup.Columns["id"].Visible = false; // Скрываем колонку ID
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке таблицы групп: {ex.Message}", "Ошибка");
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            // Открытие формы для добавления группы
            AddGroupForm addGroupForm = new AddGroupForm();
            addGroupForm.ShowDialog();

            // Обновляем данные после добавления
            LoadGroupsTable();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewGroup.SelectedRows.Count > 0)
            {
                var id = dataGridViewGroup.SelectedRows[0].Cells["id"].Value;

                try
                {
                    using (var connection = new NpgsqlConnection(connectionString))
                    {
                        connection.Open();

                        string query = "DELETE FROM groups WHERE id = @Id";
                        using (var command = new NpgsqlCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@Id", id);
                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Группа успешно удалена.", "Успех");
                    LoadGroupsTable(); // Обновляем DataGridView
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении группы: {ex.Message}", "Ошибка");
                }
            }
            else
            {
                MessageBox.Show("Выберите строку для удаления.", "Внимание");
            }
        }

        private void textBoxGroupSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = textBoxGroupSearch.Text.Trim();
            LoadGroupsTable(searchText);
        }
    }
}
