﻿namespace Schedule
{
    partial class AddRoomForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            roomNameTextBox = new TextBox();
            buttonSave = new Button();
            labelNum = new Label();
            SuspendLayout();
            // 
            // roomNameTextBox
            // 
            roomNameTextBox.Location = new Point(179, 14);
            roomNameTextBox.Name = "roomNameTextBox";
            roomNameTextBox.Size = new Size(125, 27);
            roomNameTextBox.TabIndex = 30;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(12, 116);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(152, 45);
            buttonSave.TabIndex = 29;
            buttonSave.Text = "Добавить";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // labelNum
            // 
            labelNum.AutoSize = true;
            labelNum.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 204);
            labelNum.Location = new Point(12, 15);
            labelNum.Name = "labelNum";
            labelNum.Size = new Size(161, 23);
            labelNum.TabIndex = 28;
            labelNum.Text = "Номер аудитории";
            // 
            // AddRoomForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(467, 173);
            Controls.Add(roomNameTextBox);
            Controls.Add(buttonSave);
            Controls.Add(labelNum);
            Name = "AddRoomForm";
            Text = "Добавить аудиторию";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox roomNameTextBox;
        private Button buttonSave;
        private Label labelNum;
    }
}