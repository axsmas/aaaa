﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using OfficeOpenXml;

namespace Schedule
{
    public class ExcelExporter
    {
        public static void ExportScheduleToExcel(string groupName, List<DataGridView> grids)
        {
            try
            {
                // Устанавливаем лицензионный контекст
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

                using (var package = new ExcelPackage())
                {
                    var workbook = package.Workbook;
                    var worksheet = workbook.Worksheets.Add("Расписание");

                    var daysOfWeek = new Dictionary<int, string>
                    {
                        { 1, "Понедельник" },
                        { 2, "Вторник" },
                        { 3, "Среда" },
                        { 4, "Четверг" },
                        { 5, "Пятница" },
                        { 6, "Суббота" }
                    };

                    int currentRow = 1;

                    // Добавляем название группы в заголовок
                    worksheet.Cells[currentRow, 1].Value = "Расписание группы: " + groupName;
                    worksheet.Cells[currentRow, 1, currentRow, grids[0].Columns.Count].Merge = true; // Объединяем ячейки для группы
                    worksheet.Cells[currentRow, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                    worksheet.Cells[currentRow, 1].Style.Font.Bold = true;
                    currentRow++;

                    // Добавляем пустую строку после заголовка группы
                    currentRow++;

                    // Добавляем данные по дням недели
                    for (int i = 0; i < grids.Count; i++)
                    {
                        var grid = grids[i];
                        var dayName = daysOfWeek[i + 1];

                        // Добавляем заголовок для дня недели
                        worksheet.Cells[currentRow, 1].Value = dayName;
                        worksheet.Cells[currentRow, 1, currentRow, grid.Columns.Count].Merge = true;
                        worksheet.Cells[currentRow, 1].Style.HorizontalAlignment = OfficeOpenXml.Style.ExcelHorizontalAlignment.Center;
                        worksheet.Cells[currentRow, 1].Style.Font.Bold = true;
                        currentRow++;

                        // Добавляем заголовки столбцов
                        for (int col = 0; col < grid.Columns.Count; col++)
                        {
                            worksheet.Cells[currentRow, col + 1].Value = grid.Columns[col].HeaderText;
                        }

                        currentRow++;

                        // Добавляем данные из DataGridView
                        for (int row = 0; row < grid.Rows.Count; row++)
                        {
                            for (int col = 0; col < grid.Columns.Count; col++)
                            {
                                worksheet.Cells[currentRow, col + 1].Value = grid.Rows[row].Cells[col].Value?.ToString();
                            }
                            currentRow++;
                        }

                        currentRow++; // Добавляем пустую строку между секциями
                    }

                    // Автоширина столбцов
                    worksheet.Cells[worksheet.Dimension.Address].AutoFitColumns();

                    // Сохранение файла
                    var saveFileDialog = new SaveFileDialog
                    {
                        Filter = "Excel Files (*.xlsx)|*.xlsx",
                        Title = "Сохранить расписание",
                        FileName = "Расписание.xlsx"
                    };

                    if (saveFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        var filePath = saveFileDialog.FileName;
                        System.IO.File.WriteAllBytes(filePath, package.GetAsByteArray());
                        MessageBox.Show($"Файл успешно сохранен в {filePath}", "Успех");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при экспорте в Excel: {ex.Message}", "Ошибка");
            }
        }
    }
}
